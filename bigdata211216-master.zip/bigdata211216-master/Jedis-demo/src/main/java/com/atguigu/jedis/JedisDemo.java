package com.atguigu.jedis;

import redis.clients.jedis.*;

import java.util.HashSet;

public class JedisDemo {

    public static void main(String[] args) {
        //Jedis jedis = getJedis();
        //Jedis jedis = getJedisFromPool();
        //Jedis jedis = getJedisFromSentinel();
        //jedis.set("username", "atguigu");
        //String username = jedis.get("username");
        //System.out.println(username);

        JedisCluster jedisCluster = getJedisFromCluster();

        jedisCluster.set("username","atguigu");
        String username = jedisCluster.get("username");
        System.out.println(username);


        //close(jedis);
    }

    private static JedisCluster jedisCluster  = null ;
    /**
     * 集群模式的jedis
     */
    public static JedisCluster getJedisFromCluster(){
        if(jedisCluster == null ){
            HashSet<HostAndPort> haps = new HashSet<HostAndPort>();
            haps.add(new HostAndPort("hadoop102",6379));
            haps.add(new HostAndPort("hadoop102",6380));
            haps.add(new HostAndPort("hadoop103",6379));
            haps.add(new HostAndPort("hadoop103",6380));


            JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
            jedisPoolConfig.setMaxTotal(10); //最大可用连接数
            jedisPoolConfig.setMaxIdle(5); //最大闲置连接数
            jedisPoolConfig.setMinIdle(5); //最小闲置连接数
            jedisPoolConfig.setBlockWhenExhausted(true); //连接耗尽是否等待
            jedisPoolConfig.setMaxWaitMillis(2000); //等待时间
            jedisPoolConfig.setTestOnBorrow(true); //取连接的时候进行一下测试 ping pong

            jedisCluster = new JedisCluster( haps , jedisPoolConfig);
        }

        return jedisCluster ;
    }





    private static  JedisSentinelPool jedisSentinelPool = null ;

    /**
     * 基于主从(哨兵)获取Jedis对象
     */
    public static Jedis getJedisFromSentinel(){
        if(jedisSentinelPool == null ){
            String masterName  = "mymaster";
            HashSet<String> sentinels = new HashSet<String>();
            sentinels.add("hadoop103:26379");
            sentinels.add("hadoop104:26379");
            JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
            jedisPoolConfig.setMaxTotal(10); //最大可用连接数
            jedisPoolConfig.setMaxIdle(5); //最大闲置连接数
            jedisPoolConfig.setMinIdle(5); //最小闲置连接数
            jedisPoolConfig.setBlockWhenExhausted(true); //连接耗尽是否等待
            jedisPoolConfig.setMaxWaitMillis(2000); //等待时间
            jedisPoolConfig.setTestOnBorrow(true); //取连接的时候进行一下测试 ping pong
            jedisSentinelPool = new JedisSentinelPool(masterName , sentinels , jedisPoolConfig) ;
        }
        Jedis jedis = jedisSentinelPool.getResource();
        return jedis;
    }


    /**
     * 基于连接池的方式获取Jedis对象
     */
    private static JedisPool jedisPool = null ;
    public static Jedis getJedisFromPool(){
        if(jedisPool == null ){
            //创建连接池对象
            String host = "hadoop102";
            int port = 6379 ;
            JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
            jedisPoolConfig.setMaxTotal(10); //最大可用连接数
            jedisPoolConfig.setMaxIdle(5); //最大闲置连接数
            jedisPoolConfig.setMinIdle(5); //最小闲置连接数
            jedisPoolConfig.setBlockWhenExhausted(true); //连接耗尽是否等待
            jedisPoolConfig.setMaxWaitMillis(2000); //等待时间
            jedisPoolConfig.setTestOnBorrow(true); //取连接的时候进行一下测试 ping pong

            jedisPool = new JedisPool(jedisPoolConfig , host , port);
        }

        Jedis jedis = jedisPool.getResource();

        return jedis ;
    }

    /**
     *  基于New的方式获取Jedis对象
     */
    public static Jedis getJedis(){
        String host = "hadoop102";
        int port = 6379 ;

        Jedis jedis = new Jedis(host, port);
        return jedis;
    }

    public static void close(Jedis jedis){
        if(jedis!=null) jedis.close();
    }

    /**
     * 测试String类型的常用方法
     */
    public static void testString(){

    }
    /**
     * 测试List类型的常用方法
     */
    public static void testList(){

    }
    /**
     * 测试Set类型的常用方法
     */
    public static void testSet(){

    }
    /**
     * 测试Zset类型的常用方法
     */
    public static void testZset(){

    }
    /**
     * 测试Hash类型的常用方法
     */
    public static void testHash(){

    }



}
