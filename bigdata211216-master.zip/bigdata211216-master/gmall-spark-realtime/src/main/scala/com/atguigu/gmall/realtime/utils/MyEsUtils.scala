package com.atguigu.gmall.realtime.utils

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializeConfig
import org.apache.http.HttpHost
import org.elasticsearch.action.bulk.BulkRequest
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.action.search.{SearchRequest, SearchResponse}
import org.elasticsearch.client.indices.GetIndexRequest
import org.elasticsearch.client.{RequestOptions, RestClient, RestClientBuilder, RestHighLevelClient}
import org.elasticsearch.common.xcontent.XContentType
import org.elasticsearch.search.SearchHit
import org.elasticsearch.search.builder.SearchSourceBuilder

import scala.collection.mutable.ListBuffer

/**
  * ES 工具类
  */
object MyEsUtils {

  def main(args: Array[String]): Unit = {
    val list: List[String] = searchByField("gmall_dau_info_2022-05-18" , "mid")

    println(list.size)
    println(list)
  }

  private var  esClient : RestHighLevelClient = create()

  def create(): RestHighLevelClient ={
    val host : String = MyPropsUtils(MyConfig.ES_HOST)
    val port : Int = MyPropsUtils(MyConfig.ES_PORT).toInt
    val httpHost:HttpHost = new HttpHost(host,port)
    val restClientBuilder: RestClientBuilder = RestClient.builder(httpHost)
    val client: RestHighLevelClient = new RestHighLevelClient(restClientBuilder)
    client
  }

  /**
    * 从指定的索引中查询某个字段的数据
    *
    */
  def searchByField(indexName : String , field : String ): List[String] ={

    //判断索引是否存在
    val getIndexRequest: GetIndexRequest = new GetIndexRequest(indexName)
    val isExists: Boolean = esClient.indices().exists(getIndexRequest,RequestOptions.DEFAULT)
    if(!isExists){
      return null
    }
    val mids: ListBuffer[String] = ListBuffer[String]()
    val searchRequest: SearchRequest = new SearchRequest(indexName)
    val searchSourceBuilder: SearchSourceBuilder = new SearchSourceBuilder()
    searchSourceBuilder.fetchSource(Array(field), null)
    searchSourceBuilder.size(50000)
    searchRequest.source(searchSourceBuilder)
    val searchResponse: SearchResponse = esClient.search(searchRequest , RequestOptions.DEFAULT)
    val hits: Array[SearchHit] = searchResponse.getHits.getHits
    for (searchHit <- hits) {
      val mid = searchHit.getSourceAsMap.get(field).toString
      mids.append(mid)
    }

    mids.toList
  }



  /**
    * 批量写入到ES中
    *
    * 索引名字
    * ( docId ,数据 )
    */
  def wirteToEs(indexName : String , datas : List[ ( String, AnyRef )] ) {
    val bulkRequest: BulkRequest = new BulkRequest(indexName)
    for ((docId, data) <- datas) {
      val indexRequest: IndexRequest = new IndexRequest()
      indexRequest.id(docId)
      indexRequest.source(JSON.toJSONString(data, new SerializeConfig(true)), XContentType.JSON)
      bulkRequest.add(indexRequest)
    }
    esClient.bulk(bulkRequest , RequestOptions.DEFAULT);
  }
}
