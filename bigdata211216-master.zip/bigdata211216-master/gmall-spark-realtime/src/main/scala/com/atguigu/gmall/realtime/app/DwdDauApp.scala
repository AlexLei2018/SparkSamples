package com.atguigu.gmall.realtime.app

import java.text.SimpleDateFormat
import java.time.{LocalDate, Period}
import java.{lang, util}
import java.util.Date

import com.alibaba.fastjson.{JSON, JSONObject}
import com.atguigu.gmall.realtime.bean.{DauInfo, PageLog}
import com.atguigu.gmall.realtime.utils.{MyBeanUtils, MyEsUtils, MyKafkaUtils, MyOffsetUtils, MyRedisUtils}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, OffsetRange}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import redis.clients.jedis.{Jedis, Pipeline}

import scala.collection.mutable.ListBuffer

/**
  * 日活宽表处理
  * 1. 准备实时环境
  * 2. 从redis中读取Offset
  * 3. 从Kafka中消费数据
  * 4. 提取Offset
  * 5. 处理数据
  *    5.1 转换数据结构
  *    5.2 去重: 自我审查 和 第三方审查
  *    5.3 维度关联
  * 6. 写入ES
  * 7. 提交Offset
  *
  */
object DwdDauApp {
  def main(args: Array[String]): Unit = {
    //还原状态
    revertState()

    //1. 准备实时环境
    val sparkConf: SparkConf = new SparkConf().setAppName("dwd_dau_app").setMaster("local[4]")
    val ssc: StreamingContext = new StreamingContext(sparkConf , Seconds(5))

    //2. 从redis中读取Offset
    val topic : String = "DWD_PAGE_TOPIC_1216"
    val groupId: String = "DWD_DAU_GROUP"
    val offsets: Map[TopicPartition, Long] = MyOffsetUtils.readOffset(topic, groupId)

    //3. 从Kafka中消费数据
    var kafkaDStream: InputDStream[ConsumerRecord[String, String]] = null
    if(offsets!= null && offsets.size >0){
      kafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,topic, groupId,offsets)
    }else{
      kafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,topic, groupId)
    }

    //4.提取Offset
    var offsetRanges: Array[OffsetRange] = null
    val offsetDStream: DStream[ConsumerRecord[String, String]] = kafkaDStream.transform(
      rdd => {
        offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        rdd
      }
    )
    //5.处理数据
    //5.1 转换数据结构
    val pageLogDStream: DStream[PageLog] = offsetDStream.map(
      consumerRecord => {
        val value: String = consumerRecord.value()
        val pageLog: PageLog = JSON.parseObject(value, classOf[PageLog])
        pageLog
      }
    )

   // pageLogDStream.print(100)

    //5.2 去重
    // 目的: 将同一个人(uid或者mid)一天中的多次访问进行去重，最终保留一条数据来表示一个人即可。
    // 去重步骤:
    // 1. 将某个mid一天中的一次访问中的多个页面去重，保留一个页面
    //    思路：将last_page_id不为空的页面过滤掉
    // 2. 将某个mid一天中的多次访问去重，最终保留一个页面
    //    思路: 通过redis来维护当天所有访问过页面的mid。经过第一步去重的数据再跟redis中维护的mid进行比对，
    //自我审查
    pageLogDStream.cache()
    pageLogDStream.foreachRDD(
      rdd => {
        println("自我审查前: " + rdd.count())
      }
    )
    val filterDStream: DStream[PageLog] = pageLogDStream.filter(
      pageLog => {
        pageLog.last_page_id == null
      }
    )
    filterDStream.cache()
    filterDStream.foreachRDD(
      rdd => {
        println("自我审查后: " + rdd.count())
        println("-------------------------------------")
      }
    )

    //第三方审查
    // filter: 一条一条数据进行过滤
    // mapPartitions: 一个分区的数据进行统一处理
    //            [A,B,C] => [A, B]
    val redisFilterDStream: DStream[PageLog] = filterDStream.mapPartitions(

      pageLogIter => {
        val pageLogList: List[PageLog] = pageLogIter.toList
        println("第三方审查前: " + pageLogList.size)
        //保留最终要的数据
        val pageLogs: ListBuffer[PageLog] = ListBuffer[PageLog]()
        val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
        val jedis: Jedis = MyRedisUtils.getJedis()
        for (pageLog <- pageLogList) {
          //获取每条数据的mid
          val mid: String = pageLog.mid
          //到redis中进行比对
          //type:   list  set
          //key :   DAU:DATE
          //value:  mid的集合
          //写入API:  lpush/rpush   sadd
          //读取API:  lrange        smembers
          //是否过期: 24小时

          /*
          //假设使用list类型
          //问题: 放到分布式计算的环境中，因为是并行执行，可能会导致每个并行度中都会进入到判断包含的逻辑中，可能会导致
          //      最终存储多条相同mid的数据
          //日期: 如果是生产环境，直接获取当前系统日期 . 目前考虑到会模拟不同天的数据，还是根据数据的日期来获取
          val ts: Long = pageLog.ts
          val dt: String = sdf.format(new Date(ts))
          val dauRedisKey : String = s"DAU:$dt"
          //从redis中将所有的mid获取出来
          val mids: util.List[String] = jedis.lrange(dauRedisKey ,0, -1)
          if(mids!=null && mids.size() > 0 ){
            if(!mids.contains(mid)){
              //将当前的mid存储到redis中
              jedis.lpush(dauRedisKey , mid)
              //将当前pageLog数据保留下来
              pageLogs.append(pageLog)
            }
          }else{
            //将当前的mid存储到redis中
            jedis.lpush(dauRedisKey , mid)
            //将当前pageLog数据保留下来
            pageLogs.append(pageLog)
          }
        */

          //使用set
          /*
          val ts: Long = pageLog.ts
          val dt: String = sdf.format(new Date(ts))
          val dauRedisKey : String = s"DAU:$dt"
          val mids: util.Set[String] = jedis.smembers(dauRedisKey)
          if(!mids.contains(mid)){
            jedis.sadd(dauRedisKey,mid)
            pageLogs.append(pageLog)
          }
          */

          val ts: Long = pageLog.ts
          val dt: String = sdf.format(new Date(ts))
          val dauRedisKey: String = s"DAU:$dt"
          val isNew: lang.Long = jedis.sadd(dauRedisKey, mid) // 将判断和写入实现了原子绑定
          if (isNew == 1L) {
            //保留当前pageLog
            pageLogs.append(pageLog)
          }

        }
        MyRedisUtils.close(jedis)
        println("第三方审查后: " + pageLogs.size)
        pageLogs.toIterator
      }
    )
    //redisFilterDStream.print(100)

    //5.3 维度关联
    // pageLog => DauInfo
    val dauInfoDStream: DStream[DauInfo] = redisFilterDStream.mapPartitions(
      pageLogIter => {
        val dauInfoes: ListBuffer[DauInfo] = ListBuffer[DauInfo]()
        val pageLogList: List[PageLog] = pageLogIter.toList
        val jedis: Jedis = MyRedisUtils.getJedis()
        val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        for (pageLog <- pageLogList) {

          val dauInfo: DauInfo = new DauInfo()

          //1. 将PageLog中已有的字段拷贝到DauInfo中
          MyBeanUtils.copyFieldByField(pageLog, dauInfo)

          //2. 补充用户维度信息
          val userId: String = pageLog.user_id
          val userRedisKey: String = s"DIM:user_info:$userId"
          val userJson: String = jedis.get(userRedisKey)
          val userJsonObj: JSONObject = JSON.parseObject(userJson)
          //获取性别
          val gender: String = userJsonObj.getString("gender") // NullPointerException
          //获取生日
          val birthday: String = userJsonObj.getString("birthday")
          //换算年龄
          val birthdayLd: LocalDate = LocalDate.parse(birthday)
          val nowLd: LocalDate = LocalDate.now()
          val period: Period = Period.between(birthdayLd, nowLd)
          val age: Int = period.getYears
          //补充到DauInfo中
          dauInfo.user_gender = gender
          dauInfo.user_age = age.toString

          //3. 补充地区维度信息
          val provinceId: String = pageLog.province_id
          val provinceRedisKey: String = s"DIM:base_province:$provinceId"
          val provinceJson: String = jedis.get(provinceRedisKey)
          val provinceJsonObj: JSONObject = JSON.parseObject(provinceJson)

          //提取维度信息
          val provinceName: String = provinceJsonObj.getString("name")
          val provinceAreaCode: String = provinceJsonObj.getString("area_code")
          val provinceIsoCode: String = provinceJsonObj.getString("iso_code")
          val provinceIso3166: String = provinceJsonObj.getString("iso_3166_2")

          //补充到DauInfo中
          dauInfo.province_name = provinceName
          dauInfo.province_area_code = provinceAreaCode
          dauInfo.province_iso_code = provinceIsoCode
          dauInfo.province_3166_2 = provinceIso3166

          //4. 处理日期字段
          val ts: Long = pageLog.ts
          val dtHr: String = sdf.format(new Date(ts))
          val dtHrArr: Array[String] = dtHr.split(" ")
          dauInfo.dt = dtHrArr(0)
          dauInfo.hr = dtHrArr(1).split(":")(0)

          //保存到结果中
          dauInfoes.append(dauInfo)
        }
        MyRedisUtils.close(jedis)
        dauInfoes.toIterator
      }
    )
    //dauInfoDStream.print(100)

    //6. 写入ES
    /**
      * 0. 封装ES工具类，完成数据的写入
      * 1. 每天的数据写入到不同的索引中， 需要做索引分割.
      *    索引名的规则: gmall_dau_info*    =》 gmall_dau_info_2022-05-18   gmall_dau_info_2022-05-19 ...
      * 2. 通过索引别名解决查询长周期数据的问题
      * 3. 每天使用的索引需要交给ES来完成, 需要提前定义好索引模板
      *
      */
    dauInfoDStream.foreachRDD(
      rdd => {
        rdd.foreachPartition(
          dauInfoIter => {
            // 将数据转换成ES工具类要求的格式
            val datas: List[(String, DauInfo)] = dauInfoIter.map( dauInfo => ( dauInfo.mid , dauInfo) ).toList
            //dt : 数据的日期
            if(datas!= null && datas.size > 0 ){
              val dauInfo: DauInfo = datas.head._2
              val ts: Long = dauInfo.ts
              val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
              val dt: String = sdf.format(new Date(ts))
              //索引名
              val indexName : String = s"gmall_dau_info_$dt"
              MyEsUtils.wirteToEs(indexName ,datas)
            }
          }
        )
        //7. 提交Offset
        MyOffsetUtils.saveOffset(topic , groupId , offsetRanges)

      }
    )

    ssc.start()
    ssc.awaitTermination()
  }

  /**
    * 状态还原
    * 程序启动时， 先进行状态还原 ， 将ES实际存储的mid覆盖到Redis中。
    */
  def revertState(): Unit ={
    //1. 从ES中查询所有的mid
    val nowLD: LocalDate = LocalDate.now()
    val indexName: String = s"gmall_dau_info_${nowLD.toString}"
    val field : String = "mid"
    val mids: List[String] = MyEsUtils.searchByField(indexName ,field)

    //删除redis中记录的mid
    val jedis: Jedis = MyRedisUtils.getJedis()
    val dauRedisKey: String = s"DAU:${nowLD.toString}"
    jedis.del(dauRedisKey)
    if(mids != null && mids.size > 0 ){
      //把ES中查到的mid重写写入到redis中
      //for (mid <- mids) {
        //jedis.sadd(dauRedisKey, mid)
      //}
      val pipeline: Pipeline = jedis.pipelined()
      for (mid <- mids) {
        pipeline.sadd(dauRedisKey , mid)
      }
      pipeline.sync() //真正的写入到Redis中
    }
    MyRedisUtils.close(jedis)
  }
}













