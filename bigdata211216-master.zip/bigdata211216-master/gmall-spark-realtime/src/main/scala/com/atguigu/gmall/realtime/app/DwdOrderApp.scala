package com.atguigu.gmall.realtime.app

import java.time.{LocalDate, Period}
import java.util

import com.alibaba.fastjson.serializer.SerializeConfig
import com.alibaba.fastjson.{JSON, JSONObject}
import com.atguigu.gmall.realtime.bean.{OrderDetail, OrderInfo, OrderWide}
import com.atguigu.gmall.realtime.utils.{MyEsUtils, MyKafkaUtils, MyOffsetUtils, MyRedisUtils}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, OffsetRange}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import redis.clients.jedis.Jedis

import scala.collection.mutable.ListBuffer

/**
  * 订单宽表任务
  * 1. 准备实时环境
  * 2. 从Redis中读取Offset * 2
  * 3. 从Kafka中消费数据 * 2
  * 4. 提取Offset * 2
  * 5. 数据处理
  *    5.1 转换数据结构
  *    5.2 维度关联
  *    5.3 双流Join
  * 6. 写入ES
  * 7. 提交Offset * 2
  */
object DwdOrderApp {
  def main(args: Array[String]): Unit = {
    //1. 准备实时环境
    val sparkConf: SparkConf = new SparkConf().setAppName("dwd_order_app").setMaster("local[4]")
    val ssc: StreamingContext = new StreamingContext(sparkConf ,Seconds(5))

    //2.从Redis中读取Offset * 2
    val orderInfoTopic : String = "DWD_ORDER_INFO_I_1216"
    val orderInfoGroupId : String = "DWD_ORDER_INFO_GROUP"
    val orderDetailTopic : String = "DWD_ORDER_DETAIL_I_1216"
    val orderDetailGroupId : String ="DWD_ORDER_DETAIL_GROUP"

    val orderInfoOffset: Map[TopicPartition, Long] = MyOffsetUtils.readOffset(orderInfoTopic ,orderInfoGroupId)
    val orderDetailOffset: Map[TopicPartition, Long] = MyOffsetUtils.readOffset(orderDetailTopic, orderDetailGroupId)

    //3. 从Kafka中消费数据 * 2
    var orderInfoKafkaDStream: InputDStream[ConsumerRecord[String, String]] = null
    if(orderInfoOffset != null && orderInfoOffset.size >0 ){
      orderInfoKafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,orderInfoTopic ,orderInfoGroupId,orderInfoOffset)
    }else{
      orderInfoKafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,orderInfoTopic ,orderInfoGroupId)
    }

    var orderDetailKafkaDStream: InputDStream[ConsumerRecord[String, String]] = null
    if(orderDetailOffset != null && orderDetailOffset.size >0 ){
      orderDetailKafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,orderDetailTopic ,orderDetailGroupId,orderDetailOffset)
    }else{
      orderDetailKafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,orderDetailTopic ,orderDetailGroupId)
    }

    //提取Offset * 2
    var  orderInfoOffsetRanges: Array[OffsetRange] = null
    val orderInfoOffsetDStream: DStream[ConsumerRecord[String, String]] = orderInfoKafkaDStream.transform(
      rdd => {
        orderInfoOffsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        rdd
      }
    )
    var orderDetailOffsetRanges: Array[OffsetRange] = null
    val orderDetailOffsetDStream: DStream[ConsumerRecord[String, String]] = orderDetailKafkaDStream.transform(
      rdd => {
        orderDetailOffsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        rdd
      }
    )

    //5. 处理数据
    //5.1 转换结构
    // OrderInfo  OrderDetail
    val orderInfoDStream: DStream[OrderInfo] = orderInfoOffsetDStream.map(
      consumerRecord => {
        val value: String = consumerRecord.value()
        val orderInfo: OrderInfo = JSON.parseObject(value, classOf[OrderInfo])
        orderInfo
      }
    )
    //orderInfoDStream.print(100)

    val orderDetailDStream: DStream[OrderDetail] = orderDetailOffsetDStream.map(
      consumerRecord => {
        val value: String = consumerRecord.value()
        val orderDetail: OrderDetail = JSON.parseObject(value, classOf[OrderDetail])
        orderDetail
      }
    )
    //orderDetailDStream.print(100)

    //5.2 维度关联
    val orderInfoDimDStream: DStream[OrderInfo] = orderInfoDStream.mapPartitions(
      orderInfoIter => {
        val orderInfoes: ListBuffer[OrderInfo] = ListBuffer[OrderInfo]()
        val jedis: Jedis = MyRedisUtils.getJedis()
        for (orderInfo <- orderInfoIter) {
          //补充用户维度
          val userId: Long = orderInfo.user_id
          val userRedisKey: String = s"DIM:user_info:$userId"
          val userJson: String = jedis.get(userRedisKey)
          val userJsonObj: JSONObject = JSON.parseObject(userJson)
          //提取gender
          val gender: String = userJsonObj.getString("gender")
          //提取生日
          val birthday: String = userJsonObj.getString("birthday")
          //转换年龄
          val birthdayLD: LocalDate = LocalDate.parse(birthday)
          val nowLD: LocalDate = LocalDate.now()
          val period: Period = Period.between(birthdayLD, nowLD)
          val age: Int = period.getYears

          //补充到OrderInfo中
          orderInfo.user_age = age
          orderInfo.user_gender = gender

          //补充地区维度
          val provinceId: Long = orderInfo.province_id
          val provinceRedisKey: String = s"DIM:base_province:$provinceId"
          val provinceJson: String = jedis.get(provinceRedisKey)
          val provinceJsonObj: JSONObject = JSON.parseObject(provinceJson)

          val provinceName: String = provinceJsonObj.getString("name")
          val provinceAreaCode: String = provinceJsonObj.getString("area_code")
          val provinceIsoCode: String = provinceJsonObj.getString("iso_code")
          val provinceIso3166: String = provinceJsonObj.getString("iso_3166_2")

          //补充到OrderInfo中
          orderInfo.province_name = provinceName
          orderInfo.province_area_code = provinceAreaCode
          orderInfo.province_iso_code = provinceIsoCode
          orderInfo.province_3166_2_code = provinceIso3166

          //补充日期字段
          val dthrArr: Array[String] = orderInfo.create_time.split(" ")
          orderInfo.create_date = dthrArr(0)
          orderInfo.create_hour = dthrArr(1).split(":")(0)

          orderInfoes.append(orderInfo)
        }
        MyRedisUtils.close(jedis)
        orderInfoes.toIterator
      }
    )
    //orderInfoDimDStream.print(100)

    //5.3 双流Join
    // 常用的Join方式:
    // 内连接 : 取交集
    // 外连接 :
    //    左外连: 左边全取， 右边取匹配
    //    右外连: 左边取匹配， 右边全取
    //    全外连: 左右全取

    // 分析:
    // 从表数据的层面考虑， orderInfo 和 orderDetail的数据一定都能Join成功.因此使用哪种join方式都OK
    // 从实际情况来考虑, 如果数据出现延迟，出现到不同的批次中， 就会Join失败. 如果使用的是内连接， Join失败的数据就会丢弃.
    // 我们接受因为数据延迟导致最终结果也延迟，我们不能接受因为数据延迟导致数据丢失问题。
    // 首先要保证不管能否Join成功，要先把数据都保留下来.再进行后续的弥补操作.

    val orderInfoKvDStream : DStream[(Long, OrderInfo)] =
        orderInfoDimDStream.map(orderInfo => (orderInfo.id , orderInfo))
    val orderDetailKvDStream: DStream[(Long, OrderDetail)] =
        orderDetailDStream.map(orderDetail => (orderDetail.order_id , orderDetail))

    //val orderJoinDStream: DStream[(Long, (OrderInfo, OrderDetail))] = orderInfoKvDStream.join(orderDetailKvDStream)
    //orderJoinDStream.print(1000000)

    val orderJoinDStream: DStream[(Long, (Option[OrderInfo], Option[OrderDetail]))] =
    orderInfoKvDStream.fullOuterJoin(orderDetailKvDStream)

    //OrderInfo：
    //  OrderInfo有， OrderDetail有， Join成功=> OrderWide => 保留
    //  OrderInfo有, OrderInfo看缓存 ,找到对应的OrderDetail=> OrderWide => 保留
    //  OrderInfo进缓存

    //OrderDetail:
    // OrderInfo没有, OrderDetail有, OrderDetail看缓存,找到对应的OrderInfo => OrderWide => 保留
    // OrderInfo没有, OrderDetail有, OrderDetail看缓存,缓存没有OrderInfo, OrderDetail缓存

    val orderWideDStream: DStream[OrderWide] = orderJoinDStream.mapPartitions(
      orderJoinIter => {

        val orderJoinList: List[(Long, (Option[OrderInfo], Option[OrderDetail]))] = orderJoinIter.toList
        val orderWides: ListBuffer[OrderWide] = ListBuffer[OrderWide]()
        val jedis: Jedis = MyRedisUtils.getJedis()
        for ((key, (orderInfoOp, orderDetailOp)) <- orderJoinList) {
          //OrderInfo
          if (orderInfoOp.isDefined) {
            //OrderInfo有
            val orderInfo: OrderInfo = orderInfoOp.get
            //orderDetail有
            if (orderDetailOp.isDefined) {
              val orderDetail: OrderDetail = orderDetailOp.get
              //封装成OrderWide
              val orderWide: OrderWide = new OrderWide(orderInfo, orderDetail)
              //存储到orderWides
              orderWides.append(orderWide)
            }

            //OrderInfo读缓存中的OrderDetail
            val orderDetailRedisKey: String = s"ORDERJOIN:ORDER_DETAIL:${orderInfo.id}"
            val orderDetails: util.Set[String] = jedis.smembers(orderDetailRedisKey)
            import scala.collection.JavaConverters._
            if (orderDetails != null && orderDetails.size() > 0) {
              for (orderDetailJson <- orderDetails.asScala) {
                val orderDetail: OrderDetail = JSON.parseObject(orderDetailJson, classOf[OrderDetail])
                //封装成orderWide
                val orderWide: OrderWide = new OrderWide(orderInfo, orderDetail)
                orderWides.append(orderWide)
              }
            }
            //OrderInfo进缓存
            //type: string
            //key:  ORDERJOIN:ORDER_INFO:ID
            //value: 当前数据的json
            //写入API: set
            //读取API: get
            //过时: 24小时
            val orderInfoRedisKey: String = s"ORDERJOIN:ORDER_INFO:${orderInfo.id}"
            jedis.set(orderInfoRedisKey, JSON.toJSONString(orderInfo, new SerializeConfig(true)))
            jedis.expire(orderInfoRedisKey, 3600 * 24)

          } else {
            //OrderInfo没有 ，OrderDetail有
            val orderDetail: OrderDetail = orderDetailOp.get

            //OrderDetail读缓存中的OrderInfo
            val orderInfoRedisKey: String = s"ORDERJOIN:ORDER_INFO:${orderDetail.order_id}"
            val orderInfoJson: String = jedis.get(orderInfoRedisKey)
            if (orderInfoJson != null && orderInfoJson.size > 0) {
              val orderInfo: OrderInfo = JSON.parseObject(orderInfoJson, classOf[OrderInfo])
              //封装成OrderWide
              val orderWide: OrderWide = new OrderWide(orderInfo, orderDetail)
              orderWides.append(orderWide)
            } else {
              //OrderDetail进缓存
              //type: set
              //key:   ORDERJOIN:ORDER_DETAIL:ORDER_ID
              //value: orderDetail的json的集合
              //写入API：sadd
              //读取API: smembers
              //过期: 24小时
              val orderDetailRedisKey: String = s"ORDERJOIN:ORDER_DETAIL:${orderDetail.order_id}"
              jedis.sadd(orderDetailRedisKey, JSON.toJSONString(orderDetail, new SerializeConfig(true)))
              jedis.expire(orderDetailRedisKey, 3600 * 24)
            }
          }
        }
        MyRedisUtils.close(jedis)
        orderWides.toIterator
      }
    )
    //orderWideDStream.print(10000000)

    //6. 写入ES

    orderWideDStream.foreachRDD(
      rdd => {
        rdd.foreachPartition(
          orderWideIter => {
            //转结构
            val datas: List[(String, OrderWide)] = orderWideIter.map( orderWide => ( orderWide.detail_id.toString , orderWide)).toList
            if(datas!= null && datas.size > 0 ){
              val orderWide: OrderWide = datas.head._2
              val dt: String = orderWide.create_date
              val indexName: String = s"gmall_order_wide_$dt"
              MyEsUtils.wirteToEs(indexName ,datas)
            }
          }
        )
        //7. 提交Offset
        MyOffsetUtils.saveOffset(orderInfoTopic ,orderInfoGroupId, orderInfoOffsetRanges)
        MyOffsetUtils.saveOffset(orderDetailTopic, orderDetailGroupId,orderDetailOffsetRanges)
      }
    )


    ssc.start()
    ssc.awaitTermination()
  }
}
