package com.atguigu.gmall.realtime.utils

import java.util.ResourceBundle

/**
  * 配置解析类，用于从配置文件中读取配置
  */
object MyPropsUtils {

  private val bundle: ResourceBundle = ResourceBundle.getBundle("config")

  def apply(key : String) ={
    bundle.getString(key)
  }

  def main(args: Array[String]): Unit = {
    println(MyPropsUtils("kafka.bootstrap.servers"))
  }
}
