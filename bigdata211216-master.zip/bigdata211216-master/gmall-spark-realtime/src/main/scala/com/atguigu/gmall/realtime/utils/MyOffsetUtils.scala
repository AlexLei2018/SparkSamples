package com.atguigu.gmall.realtime.utils

import java.util

import org.apache.kafka.common.TopicPartition
import org.apache.spark.streaming.kafka010.OffsetRange
import redis.clients.jedis.Jedis

import scala.collection.mutable

/**
  * 偏移量管理工具类， 用于基于redis进行偏移量的存储和读取.
  */
object MyOffsetUtils {

  /**
    * 将偏移量存储到redis中
    *
    * Kafka中的offset信息: group + topic + partition => offset
    *
    * Redis中如何存储:
    * type:   hash
    * key :   offsets:groupId:topic
    * value : partition-offset ....
    * 写入API: hset
    * 读取API: hgetall
    * 是否过期: 不过期
    *
    */
  def  saveOffset(topic : String , groupId : String , offsetRanges: Array[OffsetRange]): Unit ={
    if(offsetRanges != null && offsetRanges.size > 0 ){
      //获取redis连接
      val jedis: Jedis = MyRedisUtils.getJedis()
      val offsets: util.HashMap[String, String] = new util.HashMap[String,String]()
      for (offsetRange <- offsetRanges) {
        //提取关键信息
        val partition: Int = offsetRange.partition
        val offset: Long = offsetRange.untilOffset
        offsets.put(partition.toString ,offset.toString)
      }
      println("保存Offset: " + offsets)
      val redisKey: String = s"offsets:${groupId}:${topic}"
      jedis.hset(redisKey , offsets)
      MyRedisUtils.close(jedis)
    }
  }

  /**
    * 从Redis中读取偏移量
    */
  def readOffset(topic : String , groupId : String ) : Map[TopicPartition, Long] ={
    val jedis: Jedis = MyRedisUtils.getJedis()
    val redisKey: String = s"offsets:${groupId}:${topic}"
    val map: util.Map[String, String] = jedis.hgetAll(redisKey)
    println("读取到Offset: " + map )
    val offsets: mutable.Map[TopicPartition, Long] = mutable.Map[TopicPartition , Long]()
    import scala.collection.JavaConverters._
    for ((partition,offset) <- map.asScala) {
      //封装TopicPartition对象
      val topicPartition: TopicPartition = new TopicPartition(topic, partition.toInt )
      offsets.put(topicPartition , offset.toLong)
    }
    MyRedisUtils.close(jedis)
    offsets.toMap
  }
}
