package com.atguigu.gmall.realtime.utils

/**
  * 配置类， 用于声明项目中所能用到的配置.
  */
object MyConfig {

  val  KAFKA_BOOTSTRAP_SERVER : String = "kafka.bootstrap.servers"
  val REDIS_HOST : String = "redis.host"
  val REDIS_PORT : String = "redis.port"
  val ES_HOST : String = "es.host"
  val ES_PORT : String = "es.port"
}
