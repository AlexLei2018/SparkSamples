package com.atguigu.gmall.realtime.app

import java.lang

import com.alibaba.fastjson.serializer.SerializeConfig
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.atguigu.gmall.realtime.bean.{PageActionLog, PageDisplayLog, PageLog, StartLog}
import com.atguigu.gmall.realtime.utils.{MyKafkaUtils, MyOffsetUtils}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, OffsetRange}
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * 日志数据消费分流
  * 1. 准备实时环境
  * 2. 从Redis中读取offset
  * 3. 从kafka中消费数据
  * 4. 提取offset
  * 5. 处理数据
  *    5.1 转换数据结构
  *    5.2 数据分流
  * 6. 刷写kafka缓冲
  * 7. 提交offset
  */
object OdsBaseLogApp {
  def main(args: Array[String]): Unit = {
    //1. 准备实时环境
    val sparkConf: SparkConf = new SparkConf().setAppName("ods_base_log_app").setMaster("local[4]")
    val ssc: StreamingContext = new StreamingContext(sparkConf , Seconds(5))

    //2. 从kafka中消费数据
    val topic : String = "ODS_BASE_LOG_1216"
    val groupId : String = "ODS_BASE_LOG_GROUP"
    //TODO 从Redis中读取offset
    val offsets: Map[TopicPartition, Long] = MyOffsetUtils.readOffset(topic, groupId)

    var kafkaDStream: InputDStream[ConsumerRecord[String, String]] = null
    if(offsets!= null && offsets.size > 0 ){
      //指定offset进行数据消费
      kafkaDStream = MyKafkaUtils.getKafkaDStream(ssc , topic , groupId,offsets)
    }else{
      //第一次, 按照kafka默认的offset进行消费
      kafkaDStream = MyKafkaUtils.getKafkaDStream(ssc , topic , groupId)
    }

    //TODO 提取本次消费到的offset
    var offsetRanges: Array[OffsetRange] = null
    val offsetDStream: DStream[ConsumerRecord[String, String]] = kafkaDStream.transform(
      rdd => {
        offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        rdd
      }
    )

    //3. 处理数据
    //3.1 转换数据结构
    val jsonObjDStream: DStream[JSONObject] = offsetDStream.map(
      consumerRecord => {
        //提取出数据
        val logData: String = consumerRecord.value()
        //转换数据结构 : 通用结构（map JsonObj....）   or  专用结构（bean）
        val jsonObj: JSONObject = JSON.parseObject(logData)
        jsonObj
      }
    )
    //jsonObjDStream.cache()
    //jsonObjDStream.print(100)

    //3.2. 分流
    /*
       数据: 页面访问日志  启动日志
       原则:
           1.如果包含错误数据的直接定义为错误数据，不进行数据的拆分处理，发往错误主题
           2.启动数据 发往启动主题
           3.页面访问日志:
             3.1 页面数据 发往页面主题
             3.2 事件数据 发送事件主题
             3.3 曝光数据 发往曝光主题
     */
    val DWD_ERROR_TOPIC : String = "DWD_ERROR_TOPIC_1216"
    val DWD_PAGE_TOPIC : String  = "DWD_PAGE_TOPIC_1216"
    val DWD_PAGE_ACTION_TOPIC : String = "DWD_PAGE_ACTION_TOPIC_1216"
    val DWD_PAGE_DISPLAY_TOPIC : String ="DWD_PAGE_DISPLAY_TOPIC_1216"
    val DWD_START_TOPIC : String = "DWD_START_TOPIC_1216"

    jsonObjDStream.foreachRDD(
      rdd => {

        rdd.foreachPartition(
          jsonObjIter => {
            //处理每个分区的数据
            for (jsonObj <- jsonObjIter) {
              // 每条数据的处理
              // 分流每一条数据
              // 分流错误数据
              val errObj: JSONObject = jsonObj.getJSONObject("err")
              if(errObj != null ){
                //发往错误主题中
                MyKafkaUtils.send(DWD_ERROR_TOPIC , jsonObj.toJSONString)
              }else{
                //提取公共字段
                val commonObj: JSONObject = jsonObj.getJSONObject("common")
                val ar: String = commonObj.getString("ar")
                val ba: String = commonObj.getString("ba")
                val ch: String = commonObj.getString("ch")
                val isNew: String = commonObj.getString("is_new")
                val md: String = commonObj.getString("md")
                val mid: String = commonObj.getString("mid")
                val os: String = commonObj.getString("os")
                val uid: String = commonObj.getString("uid")
                val vc: String = commonObj.getString("vc")

                //提取ts
                val ts: lang.Long = jsonObj.getLong("ts")


                val pageObj: JSONObject = jsonObj.getJSONObject("page")
                if(pageObj != null ){
                  // 页面数据
                  val duringTime: lang.Long = pageObj.getLong("during_time")
                  val pageItem: String = pageObj.getString("item")
                  val pageItemType: String = pageObj.getString("item_type")
                  val lastPageId: String = pageObj.getString("last_page_id")
                  val pageId: String = pageObj.getString("page_id")
                  val sourceType: String = pageObj.getString("sourceType")

                  //封装成一条页面数据
                  val pageLog: PageLog =
                    PageLog(mid,uid,ar,ch,isNew,md,os,vc,ba,pageId,lastPageId,pageItem,pageItemType,duringTime,sourceType,ts)

                  //发送到页面访问主题
                  MyKafkaUtils.send(DWD_PAGE_TOPIC , JSON.toJSONString(pageLog,new SerializeConfig(true)))

                  //事件
                  val actionArrObj: JSONArray = jsonObj.getJSONArray("actions")
                  if(actionArrObj!=null && actionArrObj.size()> 0){
                    for( i <- 0 until actionArrObj.size()){
                      val actionObj: JSONObject = actionArrObj.getJSONObject(i)
                      //提取事件字段
                      val actionId: String = actionObj.getString("action_id")
                      val actionItem: String = actionObj.getString("item")
                      val actionItemType: String = actionObj.getString("item_type")
                      val actionTs: lang.Long = actionObj.getLong("ts")
                      //封装成一条事件数据
                      val pageActionLog: PageActionLog =
                        PageActionLog(mid,uid,ar,ch,isNew,md,os,vc,ba,pageId,lastPageId,pageItem,pageItemType,duringTime,sourceType,actionId,actionItem,actionItemType,actionTs,ts)
                      //发送事件主题
                      MyKafkaUtils.send(DWD_PAGE_ACTION_TOPIC ,JSON.toJSONString(pageActionLog,new SerializeConfig(true)) )
                    }
                  }

                  //曝光(课下完成)
                  val displayArrObj: JSONArray = jsonObj.getJSONArray("displays")
                  if(displayArrObj != null  && displayArrObj.size() >0 ){
                    for(i <- 0 until displayArrObj.size()){
                      val displayObj: JSONObject = displayArrObj.getJSONObject(i)
                      //提取曝光字段
                      val displayType: String = displayObj.getString("display_type")
                      val displayItem: String = displayObj.getString("item")
                      val displayItemType: String = displayObj.getString("item_type")
                      val order: String = displayObj.getString("order")
                      val posId: String = displayObj.getString("pos_id")

                      //封装成一条曝光数据
                      val pageDisplayLog: PageDisplayLog =
                        PageDisplayLog(mid,uid,ar,ch,isNew, md, os, vc,ba,pageId,lastPageId,pageItem,pageItemType,duringTime,sourceType,displayType,displayItem,displayItemType,order,posId,ts)
                      //发送到曝光主题
                      MyKafkaUtils.send(DWD_PAGE_DISPLAY_TOPIC , JSON.toJSONString(pageDisplayLog ,new SerializeConfig(true)))
                    }
                  }
                }

                val startObj: JSONObject = jsonObj.getJSONObject("start")
                if(startObj != null ){
                  // 启动数据(课下完成)
                  val entry: String = startObj.getString("entry")
                  val loadingTime: lang.Long = startObj.getLong("loading_time")
                  val openAdId: String = startObj.getString("open_ad_id")
                  val openAdMs: lang.Long = startObj.getLong("open_ad_ms")
                  val openAdSkipMs: lang.Long = startObj.getLong("open_ad_skip_ms")

                  //封装成一条启动数据
                  val startLog: StartLog =
                    StartLog(mid,uid,ar,ch,isNew,md,os,vc,ba,entry,openAdId,loadingTime,openAdMs,openAdSkipMs,ts)
                  //发送到启动主题
                  MyKafkaUtils.send(DWD_START_TOPIC, JSON.toJSONString(startLog,new SerializeConfig(true)))
                }
              }
            }
            // D : foreachPartition里面，for循环外面:  Executor端 ， 每批次每分区执行一次.
            MyKafkaUtils.flush()
          }
        )
        /*
        rdd.foreach(
          jsonObj => {
            // 分流每一条数据
            // 分流错误数据
            val errObj: JSONObject = jsonObj.getJSONObject("err")
            if(errObj != null ){
              //发往错误主题中
              MyKafkaUtils.send(DWD_ERROR_TOPIC , jsonObj.toJSONString)
            }else{
              //提取公共字段
              val commonObj: JSONObject = jsonObj.getJSONObject("common")
              val ar: String = commonObj.getString("ar")
              val ba: String = commonObj.getString("ba")
              val ch: String = commonObj.getString("ch")
              val isNew: String = commonObj.getString("is_new")
              val md: String = commonObj.getString("md")
              val mid: String = commonObj.getString("mid")
              val os: String = commonObj.getString("os")
              val uid: String = commonObj.getString("uid")
              val vc: String = commonObj.getString("vc")

              //提取ts
              val ts: lang.Long = jsonObj.getLong("ts")


              val pageObj: JSONObject = jsonObj.getJSONObject("page")
              if(pageObj != null ){
                // 页面数据
                val duringTime: lang.Long = pageObj.getLong("during_time")
                val pageItem: String = pageObj.getString("item")
                val pageItemType: String = pageObj.getString("item_type")
                val lastPageId: String = pageObj.getString("last_page_id")
                val pageId: String = pageObj.getString("page_id")
                val sourceType: String = pageObj.getString("sourceType")

                //封装成一条页面数据
                val pageLog: PageLog =
                    PageLog(mid,uid,ar,ch,isNew,md,os,vc,ba,pageId,lastPageId,pageItem,pageItemType,duringTime,sourceType,ts)

                //发送到页面访问主题
                MyKafkaUtils.send(DWD_PAGE_TOPIC , JSON.toJSONString(pageLog,new SerializeConfig(true)))

                //事件
                val actionArrObj: JSONArray = jsonObj.getJSONArray("actions")
                if(actionArrObj!=null && actionArrObj.size()> 0){
                  for( i <- 0 until actionArrObj.size()){
                    val actionObj: JSONObject = actionArrObj.getJSONObject(i)
                    //提取事件字段
                    val actionId: String = actionObj.getString("action_id")
                    val actionItem: String = actionObj.getString("item")
                    val actionItemType: String = actionObj.getString("item_type")
                    val actionTs: lang.Long = actionObj.getLong("ts")
                    //封装成一条事件数据
                     val pageActionLog: PageActionLog =
                       PageActionLog(mid,uid,ar,ch,isNew,md,os,vc,ba,pageId,lastPageId,pageItem,pageItemType,duringTime,sourceType,actionId,actionItem,actionItemType,actionTs,ts)
                    //发送事件主题
                    MyKafkaUtils.send(DWD_PAGE_ACTION_TOPIC ,JSON.toJSONString(pageActionLog,new SerializeConfig(true)) )
                  }
                }

                //曝光(课下完成)
                val displayArrObj: JSONArray = jsonObj.getJSONArray("displays")
                if(displayArrObj != null  && displayArrObj.size() >0 ){
                  for(i <- 0 until displayArrObj.size()){
                    val displayObj: JSONObject = displayArrObj.getJSONObject(i)
                    //提取曝光字段
                    val displayType: String = displayObj.getString("display_type")
                    val displayItem: String = displayObj.getString("item")
                    val displayItemType: String = displayObj.getString("item_type")
                    val order: String = displayObj.getString("order")
                    val posId: String = displayObj.getString("pos_id")

                    //封装成一条曝光数据
                    val pageDisplayLog: PageDisplayLog =
                      PageDisplayLog(mid,uid,ar,ch,isNew, md, os, vc,ba,pageId,lastPageId,pageItem,pageItemType,duringTime,sourceType,displayType,displayItem,displayItemType,order,posId,ts)
                    //发送到曝光主题
                    MyKafkaUtils.send(DWD_PAGE_DISPLAY_TOPIC , JSON.toJSONString(pageDisplayLog ,new SerializeConfig(true)))
                  }
                }
              }

              val startObj: JSONObject = jsonObj.getJSONObject("start")
              if(startObj != null ){
                // 启动数据(课下完成)
                val entry: String = startObj.getString("entry")
                val loadingTime: lang.Long = startObj.getLong("loading_time")
                val openAdId: String = startObj.getString("open_ad_id")
                val openAdMs: lang.Long = startObj.getLong("open_ad_ms")
                val openAdSkipMs: lang.Long = startObj.getLong("open_ad_skip_ms")

                //封装成一条启动数据
                val startLog: StartLog =
                    StartLog(mid,uid,ar,ch,isNew,md,os,vc,ba,entry,openAdId,loadingTime,openAdMs,openAdSkipMs,ts)
                //发送到启动主题
                MyKafkaUtils.send(DWD_START_TOPIC, JSON.toJSONString(startLog,new SerializeConfig(true)))
              }
            }
            //A: foreach里面:   Executor端 ,  每批次中的每条数据执行一次.
            //MyKafkaUtils.flush() 相当于是同步写。每条数据都进行了flush
          }
        )
        */
        //B: foreachRDD里面 ,foreach外面:  Driver端 , 每批次执行一次
        //MyKafkaUtils.flush() //KafkaProducer
        MyOffsetUtils.saveOffset(topic , groupId , offsetRanges)
      }
    )
    //C: foreachRDD外面 : Driver端 , 程序启动时执行一次。
    ssc.start()
    ssc.awaitTermination()
  }
}
