package com.atguigu.gmall.realtime.utils

import java.lang.reflect.{Field, Method, Modifier}

import com.atguigu.gmall.realtime.bean.{DauInfo, PageLog}

import scala.util.control.Breaks

/**
  * 对象属性拷贝
  */
object MyBeanUtils {

  def main(args: Array[String]): Unit = {

    val pageLog: PageLog =
      PageLog("m1001", "u1001", "p1001" ,null ,null ,null ,null ,null ,null ,"page1001" ,null ,null ,null ,123L, null ,456L)
    val dauInfo: DauInfo = new DauInfo()

    //copyFieldByField(pageLog , dauInfo)
    copyFieldByMethod(pageLog , dauInfo)

    println(dauInfo)

  }
  def copyFieldByMethod(srcObj : AnyRef , destObj : AnyRef): Unit ={
    //1. 从源对象中获取所有的属性
    val srcFields: Array[Field] = srcObj.getClass.getDeclaredFields
    //2. 迭代源对象的所有属性，
    for (srcField <- srcFields) {
      Breaks.breakable{
        // 开权限
        srcField.setAccessible(true)
        //获取属性名
        val srcFieldName: String = srcField.getName
        //尝试从目标对象中查找该属性
        val destField: Field =
          try{
            destObj.getClass.getDeclaredField(srcFieldName)
          }catch{
            case ex : NoSuchFieldException => Breaks.break()
          }
        //开权限
        //destField.setAccessible(true)
        //判断目标对象的属性是否是final修饰
        if(destField.getModifiers.equals(Modifier.FINAL)) Breaks.break()

        //构造属性对应的get方法 和 set方法
        //getMethoName
        val getMethodName : String = srcField.getName
        //setMethodName
        val setMethodName : String = srcField.getName + "_$eq"

        //从源对象中获取属性对应的get方法
        val getMethod: Method = srcObj.getClass.getDeclaredMethod(getMethodName)
        //从目标对象中获取属性对应的set方法
        val setMethod: Method = destObj.getClass.getDeclaredMethod(setMethodName , destField.getType)

        //从源对象中获取属性的值
        val srcFieldValue: AnyRef = getMethod.invoke(srcObj)
        //给目标对象属性赋值
        setMethod.invoke(destObj ,srcFieldValue)
      }
    }
  }



  /**
    *
    * @param srcObj  被拷贝对象
    * @param destObj 目标对象
    */
  def copyFieldByField(srcObj : AnyRef , destObj : AnyRef): Unit ={
    //1. 从源对象中获取所有的属性
    val srcFields: Array[Field] = srcObj.getClass.getDeclaredFields
    //2. 迭代源对象的所有属性，
    for (srcField <- srcFields) {
      Breaks.breakable{
        // 开权限
        srcField.setAccessible(true)
        //获取属性名
        val srcFieldName: String = srcField.getName
        //尝试从目标对象中查找该属性
        val destField: Field =
        try{
           destObj.getClass.getDeclaredField(srcFieldName)
        }catch{
          case ex : NoSuchFieldException => Breaks.break()
        }
        //开权限
        destField.setAccessible(true)
        //判断目标对象的属性是否是final修饰
        if(destField.getModifiers.equals(Modifier.FINAL)) Breaks.break()

        //获取源对象属性的值
        val srcFieldValue: AnyRef = srcField.get(srcObj)
        //赋值给目标对象的属性
        destField.set(destObj,srcFieldValue)
      }
    }
  }
}
