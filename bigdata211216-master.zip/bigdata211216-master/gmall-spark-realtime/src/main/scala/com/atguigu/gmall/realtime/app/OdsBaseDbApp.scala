package com.atguigu.gmall.realtime.app

import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.atguigu.gmall.realtime.utils.{MyKafkaUtils, MyOffsetUtils, MyRedisUtils}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.spark.SparkConf
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, OffsetRange}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import redis.clients.jedis.Jedis

/**
  * 业务数据消费分流
  * 1. 准备实时环境
  * 2. 从Redis中读取offset
  * 3. 从Kakfa中消费数据
  * 4. 提取offset
  * 5. 处理数据
  *    5.1 转换数据结构
  *    5.2 分流
  * 6. 刷写kafka缓冲
  * 7. 提交offset
  *
  */
object OdsBaseDbApp {
  def main(args: Array[String]): Unit = {
    //1. 准备实时环境
    val sparkConf: SparkConf = new SparkConf().setAppName("ods_base_db_app").setMaster("local[4]")
    val ssc: StreamingContext = new StreamingContext(sparkConf , Seconds(5))

    //2. 从Redis中读取offset
    val topic : String = "ODS_BASE_DB_1216"
    val groupId : String = "ODS_BASE_DB_GROUP"
    val offsets: Map[TopicPartition, Long] = MyOffsetUtils.readOffset(topic , groupId)

    //3. 从kafka中消费数据
    var kafkaDStream: InputDStream[ConsumerRecord[String, String]] = null
    if(offsets!= null && offsets.size >0 ){
      //指定offset进行消费
      kafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,topic, groupId, offsets)
    }else{
      //默认offset进行消费
      kafkaDStream = MyKafkaUtils.getKafkaDStream(ssc,topic, groupId)
    }

    //4. 提取offset
    var offsetRanges: Array[OffsetRange] = null
    val offsetDStream: DStream[ConsumerRecord[String, String]] = kafkaDStream.transform(
      rdd => {
        offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        rdd
      }
    )
    //5.分流
    //5.1 转换结构
    val jsonObjDStream: DStream[JSONObject] = offsetDStream.map(
      consumerRecord => {
        val value: String = consumerRecord.value()
        val jsonObj: JSONObject = JSON.parseObject(value)
        jsonObj
      }
    )
    //jsonObjDStream.print(100)

    //5.2 分流
    // 事实数据 -> 以表为基础、以操作（insert 、 update 、 delete ....）为单位 -> 分流到Kafka对应的主题
    // 维度数据 -> 以每条数据为单位 -> 分流到Redis中

    // 如何实现动态维护表清单?
    // 将表清单维护到redis中，代码中动态读取redis中维护的表清单.
    //声明事实表清单
    //val factTables : Set[String] = Set[String]("order_info", "order_detail" /*将需要的表定义到这*/)
    //声明维度表清单
    //val dimTables : Set[String] = Set[String]("user_info" , "base_province" /*将需要的表定义到这*/)

    //C: Driver端，程序启动执行一次.
    jsonObjDStream.foreachRDD(
      rdd => {
        //B: Driver端, 每批次

        //在此处读取redis中维护的表清单， 保证每批次都可以读取一次， 当redis中的表清单发生改变， 在下个批次就可以生效.
        //type:  set
        //key :  FACT:TABLES  DIM:TABLES
        //value: 表名的集合
        //写入API: sadd
        //读取API: smembers
        //是否过期: 不过期
        val jedis: Jedis = MyRedisUtils.getJedis()
        //事实表清单的key
        val factTablesKey : String = "FACT:TABLES"
        //维度表清单的key
        val dimTableKey : String = "DIM:TABLES"
        //从redis中读取表清单
        val factTables: util.Set[String] = jedis.smembers(factTablesKey)
        println("factTables: " + factTables )
        //做成广播变量
        val factTablesBC: Broadcast[util.Set[String]] = ssc.sparkContext.broadcast(factTables)
        val dimTables: util.Set[String] = jedis.smembers(dimTableKey)
        println("dimTables: " + dimTables)
        //做成广播变量
        val dimTablesBC: Broadcast[util.Set[String]] = ssc.sparkContext.broadcast(dimTables)
        MyRedisUtils.close(jedis)

        //处理当前批次的数据
        rdd.foreachPartition(
          //处理当前批次某个分区的数据
          jsonObjIter => {
            //A : Executor端, 每批次每分区
            val jedis: Jedis = MyRedisUtils.getJedis()
            for (jsonObj <- jsonObjIter) {
              //处理当前批次某个分区中的某条数据
              //明确当前数据的操作类型 : 1. 过滤掉不感兴趣的数据   2.记录当前数据的操作类型
              val operType: String = jsonObj.getString("type")
              val op: String = operType match {
                case "insert" => "I"
                case "update" => "U"
                case "bootstrap-insert" => "I"
                case _ => null
              }
              if(op != null){
                //提取表名
                val tableName: String = jsonObj.getString("table")
                if(factTablesBC.value.contains(tableName)){
                  //事实表数据
                  //提取data
                  val dataObj: JSONObject = jsonObj.getJSONObject("data")
                  // DWD_ORDER_INFO_I_1216  DWD_ORDER_INFO_U_1216
                  val dwd_fact_topic : String = s"DWD_${tableName.toUpperCase}_${op}_1216"
                  MyKafkaUtils.send(dwd_fact_topic , dataObj.toJSONString)
                  //模拟数据延迟
                  if(tableName.equals("order_detail")){
                    Thread.sleep(200)
                  }
                }
                if(dimTablesBC.value.contains(tableName)){
                  //维度表数据
                  val dataObj: JSONObject = jsonObj.getJSONObject("data")
                  //写入到Redis中
                  //在此处开启redis连接好不好??
                  //不好,每条数据都开一个连接太频繁.
                  //val jedis: Jedis = MyRedisUtils.getJedis()
                  //type:  String
                  //如果考虑将一个表的数据通过一个kv来进行存储， 可以使用hash类型, field存成用户的id,value存成一条用户信息的json格式
                  //   这种方案要考虑存储的数据量大不大，因为一个kv的数据只能存到一起.

                  //如果考虑一条数据通过一个kv来进行存储，
                  //  可以使用string类型， k存成用户的id,value存成一条用户信息的json
                  //  可以使用hash类型, k存成用户的id， field就是用户的每个字段，value就是每个字段值

                  //key:   DIM:表名:id
                  //value: 一条数据的json
                  //写入API: set
                  //读取API: get
                  //是否过期:不过期

                  //从data中提取当前数据的id
                  val id: String = dataObj.getString("id")
                  val dimRedisKey : String = s"DIM:${tableName}:$id"
                  jedis.set(dimRedisKey,  dataObj.toJSONString)
                  //MyRedisUtils.close(jedis)
                }
              }
            }
            MyRedisUtils.close(jedis)
            //6.刷写Kafka缓冲区
            MyKafkaUtils.flush()
          }
        )
        //7. 提交offset
        MyOffsetUtils.saveOffset(topic , groupId , offsetRanges)
      }
    )

    ssc.start()
    ssc.awaitTermination()
  }

}
