package com.atguigu.phoenix.thin;

import org.apache.phoenix.queryserver.client.ThinClientUtil;

import java.sql.*;
import java.util.Properties;

/**
 * 瘦客户端
 */
public class ThinDemo {

    public static void main(String[] args) throws SQLException {
        testSelect();
    }

    /**
     * 获取连接   编写SQL  预编译  设置占位  执行SQL  处理结果  关闭连接
     */
    public static void testSelect() throws SQLException {
        String url = "jdbc:phoenix:thin:url=http://hadoop102:8765;serialization=PROTOBUF";
        String connectionUrl = ThinClientUtil.getConnectionUrl("hadoop102", 8765);
        Connection connection = DriverManager.getConnection(connectionUrl);
        String sql = "select id, name, age from stu where id = ? " ;
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, "1001");
        ResultSet resultSet = ps.executeQuery();
        if(resultSet.next()){
            String id = resultSet.getString("ID");  //1
            String name = resultSet.getString("NAME");//2
            int age = resultSet.getInt("AGE");//3
            System.out.println(id + " : " + name + " : " + age  );
        }

        resultSet.close();
        ps.close();
        connection.close();
    }

}
