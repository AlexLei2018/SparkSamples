package com.atguigu.phoenix.thick;

import java.sql.*;
import java.util.Properties;

/**
 * 胖客户端测试
 */
public class ThickDemo {

    public static void main(String[] args) throws SQLException {
        testSelect();
    }

    /**
     * 获取连接   编写SQL  预编译  设置占位  执行SQL  处理结果  关闭连接
     */
    public static void testSelect() throws SQLException {
        String url = "jdbc:phoenix:hadoop102,hadoop103,hadoop104:2181";
        Properties props = new Properties();
        props.put("phoenix.schema.isNamespaceMappingEnabled" , "true");
        Connection connection = DriverManager.getConnection(url,props);
        String sql = "select id, name, age from stu where id = ? " ;
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, "1001");
        ResultSet resultSet = ps.executeQuery();
        if(resultSet.next()){
            String id = resultSet.getString("ID");  //1
            String name = resultSet.getString("NAME");//2
            int age = resultSet.getInt("AGE");//3
            System.out.println(id + " : " + name + " : " + age  );
        }

        resultSet.close();
        ps.close();
        connection.close();
    }



    public static void testUpsert(){

    }

    public static void testDelete(){

    }
}
