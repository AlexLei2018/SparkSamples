package com.atguigu.hbase;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class HbaseDemo {

    public static void main(String[] args) throws IOException {
        //System.out.println(connection);
        //createTable(null ,  "emp" , "info1" , "info2");
        //putData(null , "emp", "1001", "info1" , "name", "zhangxiaosan");
        //deleteData(null, "stu" , "10021" , "info" ,"name"  );
        //getData(null , "stu" , "1003");
        scanData(null ,"stu" , "10021" ,"100|" );

    }
    /**
     * DML - 查询数据 - scan
     * 扫描指定rowkey范围的数据
     */
    public static void scanData(String namespace , String tableName , String startRow, String stopRow ) throws IOException {
        TableName tn = TableName.valueOf(namespace, tableName);
        Table table = connection.getTable(tn);
        Scan scan = new Scan();
        scan.withStartRow(Bytes.toBytes(startRow)).withStopRow(Bytes.toBytes(stopRow));
        ResultScanner scanner = table.getScanner(scan);
        Iterator<Result> iterator = scanner.iterator();
        while(iterator.hasNext()){
            Result next = iterator.next();
            List<Cell> cells = next.listCells();
            for (Cell cell : cells) {
                String line = Bytes.toString(CellUtil.cloneRow(cell)) + " : " +
                        Bytes.toString(CellUtil.cloneFamily(cell)) + " : " +
                        Bytes.toString(CellUtil.cloneQualifier(cell)) + " : " +
                        Bytes.toString(CellUtil.cloneValue(cell));
                System.out.println(line);
            }
            System.out.println("---------------------------------------");
        }
        table.close();
    }


    /**
     * DML - 查询数据 - get
     * 查询指定rowkey的数据
     */
    public static void getData(String namespace , String tableName,String rk ) throws IOException {
        TableName tn = TableName.valueOf(namespace, tableName);
        Table table = connection.getTable(tn);
        Get get = new Get(Bytes.toBytes(rk));
        //get.addFamily(); // 指定查询某个列族的数据
        //get.addColumn();// 指定查询某个列的数据
        Result result = table.get(get);
        List<Cell> cells = result.listCells();
        for (Cell cell : cells) {
            String line = Bytes.toString(CellUtil.cloneRow(cell)) + " : " +
                    Bytes.toString(CellUtil.cloneFamily(cell)) + " : " +
                    Bytes.toString(CellUtil.cloneQualifier(cell)) + " : " +
                    Bytes.toString(CellUtil.cloneValue(cell));
            System.out.println(line);
        }

        table.close();
    }



    /**
     * DML - 删除数据
     * 1. 删除一个列一个版本的数据 Delete
     * 2. 删除一个列所有版本的数据  DeleteColumn
     * 3. 删除一个列族的数据  DeleteFamily
     */
    public static void deleteData(String namespace, String tableName , String rk , String cf, String cl ) throws IOException {
        TableName tn = TableName.valueOf(namespace, tableName);
        Table table = connection.getTable(tn);
        //只指定rowkey，表示删除整条数据,具体就是直接删除每个列族 ( DeleteFamily)
        Delete delete = new Delete(Bytes.toBytes(rk));
        //指定列族， 表示删除指定列族的数据(DeleteFamily)
        //delete.addFamily(Bytes.toBytes(cf));
        //执行列族和列
        //delete.addColumn(Bytes.toBytes(cf), Bytes.toBytes(cl)); // 删除指定版本的数据，默认最新版本(Delete)
        delete.addColumns(Bytes.toBytes(cf), Bytes.toBytes(cl));// 删除所有版本的数据（DeleteColumn）
        table.delete(delete);
        table.close();
    }

    /**
     * DML - 插入数据/修改数据
     * put 'ns:tn' , 'rk'  , 'cf:cl' , 'v'
     */
    public static void putData(String namespace , String tableName , String rk, String cf, String cl , String value) throws IOException {
        //获取Table对象
        TableName tn = TableName.valueOf(namespace, tableName);
        Table table = connection.getTable(tn);
        Put put = new Put(Bytes.toBytes(rk));
        put.addColumn(Bytes.toBytes(cf) , Bytes.toBytes(cl) , Bytes.toBytes(value));
        table.put(put);

        table.close();
    }


    /**
     * DDL - 创建表
     * create 'ns:tn' , 'cf' ...
     */
    public static void createTable(String namespace , String tableName , String ... cfs ) throws IOException {
        //获取Admin对象
        Admin admin = connection.getAdmin();
        //先判断表是否已经存在
        TableName tn = TableName.valueOf(namespace, tableName);
        boolean exists = admin.tableExists(tn);
        if(exists){
            System.err.println((namespace==null?"default":namespace) + ":"+tableName +" 表已经存在");
            return ;
        }
        //创建表
        TableDescriptorBuilder tableDescriptorBuilder = TableDescriptorBuilder.newBuilder(tn);
        //设置列族
        for (String cf : cfs) {
            ColumnFamilyDescriptorBuilder columnFamilyDescriptorBuilder =
                    ColumnFamilyDescriptorBuilder.newBuilder(Bytes.toBytes(cf));
            ColumnFamilyDescriptor columnFamilyDescriptor = columnFamilyDescriptorBuilder.build();
            tableDescriptorBuilder.setColumnFamily(columnFamilyDescriptor);
        }

        TableDescriptor tableDescriptor = tableDescriptorBuilder.build();

        admin.createTable(tableDescriptor);
        System.out.println((namespace==null?"default":namespace) + ":"+tableName +" 表创建成功");
        admin.close();
    }

    /**
     * 创建connection对象
     */
    private static Connection connection ;

    static{
        //Configuration configuration = new Configuration();
        Configuration configuration = HBaseConfiguration.create();
        //指定hbase的地址
        configuration.set("hbase.zookeeper.quorum", "hadoop102,hadoop103,hadoop104");
        try {
            connection = ConnectionFactory.createConnection(configuration);
        } catch (IOException e) {

        }
    }

}
