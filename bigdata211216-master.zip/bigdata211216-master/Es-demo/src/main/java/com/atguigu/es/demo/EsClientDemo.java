package com.atguigu.es.demo;

import com.alibaba.fastjson.JSON;
import org.apache.http.HttpHost;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.*;
import org.elasticsearch.index.reindex.DeleteByQueryRequest;
import org.elasticsearch.index.reindex.UpdateByQueryRequest;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.AvgAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.ParsedAvg;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.SortOrder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ES 客户端
 */
public class EsClientDemo {

    public static void main(String[] args) throws IOException {
        //System.out.println(esClient);

        //insertData();
        //bulkInsertData();
        //updateData();
        //updateDataByQuery();
        //deleteData();
        //deleteDataByQuery();
        //searchById();
        //searchByFilter();
        searchByAgg();

        esClient.close();
    }

    /**
     * 聚合查询
     *
     * 查询每位演员参演的电影的平均分，倒叙排序
     */
    public static void searchByAgg() throws IOException {
        String indexName = "movie_index";
        SearchRequest searchRequest = new SearchRequest(indexName);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        //不要明细数据
        searchSourceBuilder.size(0);
        //agg
        //group
        TermsAggregationBuilder termsAggregationBuilder = AggregationBuilders.
                terms("groupbyactorname").
                field("actorList.name.keyword").
                size(10).
                order(BucketOrder.aggregation("avgdoubanscore" , false ));
        //avg
        AvgAggregationBuilder avgAggregationBuilder =
                AggregationBuilders.avg("avgdoubanscore").field("doubanScore");
        termsAggregationBuilder.subAggregation(avgAggregationBuilder);
        searchSourceBuilder.aggregation(termsAggregationBuilder);

        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse =
                    esClient.search(searchRequest, RequestOptions.DEFAULT);
        Aggregations aggregations = searchResponse.getAggregations();
        ParsedTerms parsedTerms = aggregations.get("groupbyactorname");
        List<? extends Terms.Bucket> buckets = parsedTerms.getBuckets();
        for (Terms.Bucket bucket : buckets) {
            //演员名字
            String actorName = bucket.getKeyAsString();
            //参演的电影个数
            long movieNums = bucket.getDocCount();
            //平均分
            Aggregations bucketAggregations = bucket.getAggregations();
            ParsedAvg parsedAvg = bucketAggregations.get("avgdoubanscore");
            double avgScore = parsedAvg.getValue();

            System.out.println("演员 " + actorName + " 共参演了 " + movieNums +" 部电影,平均 " + avgScore + " 分");
        }
    }


    /**
     * 条件查询
     *
     *     * search :
     *     *
     *     * 查询doubanScore>=5.0 关键词搜索red sea
     *     * 关键词高亮显示
     *     * 显示第一页，每页2条
     *     * 按doubanScore从大到小排序
     *
     */
    public static void searchByFilter() throws IOException {
        String indexName = "movie_index";
        SearchRequest searchRequest = new SearchRequest(indexName);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        //query
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        //filter
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery("doubanScore").gte(5.0);
        boolQueryBuilder.filter( rangeQueryBuilder);

        //must
        MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("name", "red sea");
        boolQueryBuilder.must(matchQueryBuilder);

        //highlight
        HighlightBuilder highlightBuilder = new HighlightBuilder();
        highlightBuilder.field("name");
        searchSourceBuilder.highlighter(highlightBuilder);

        //分页
        //查看第一页 每页两条
        Integer pageNum  = 1 ;
        Integer pageSize = 2 ;
        searchSourceBuilder.from( ( pageNum -1 )  * pageSize );
        searchSourceBuilder.size( pageSize );

        //sort
        searchSourceBuilder.sort("doubanScore", SortOrder.DESC);

        searchSourceBuilder.query(boolQueryBuilder);

        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse =
                esClient.search(searchRequest, RequestOptions.DEFAULT);
        //处理结果
        SearchHit[] searchHits = searchResponse.getHits().getHits();
        for (SearchHit searchHit : searchHits) {
            //提取数据
            Map<String, Object> source = searchHit.getSourceAsMap();
            System.out.println("source before: "  + source);
            //提取高亮
            Map<String, HighlightField> highlightFields = searchHit.getHighlightFields();
            HighlightField highlightField = highlightFields.get("name");
            Text[] fragments = highlightField.getFragments();
            String highlight = fragments[0].toString();
            //将高亮字段替换到数据中
            source.put("name",highlight);
            System.out.println("source after: " + source);
        }
    }






    /**
     * 基于docId查询
     *
     * Request : 请求
     * Response: 响应
     */
    public static void searchById() throws IOException {
        String indexName = "movie_test_api";
        String docId = "1004" ;
        GetRequest getRequest = new GetRequest(indexName,docId);
        GetResponse getResponse = esClient.get(getRequest, RequestOptions.DEFAULT);
        String source = getResponse.getSourceAsString();
        System.out.println(source);
    }




    /**
     * 基于docId删除数据
     */
    public static void deleteData() throws IOException {
        String indexName = "movie_test_api" ;
        String docId  = "v0PF1YAB579J1YxZTE88";
        DeleteRequest deleteRequest = new DeleteRequest(indexName,docId);
        esClient.delete(deleteRequest, RequestOptions.DEFAULT) ;
    }

    /**
     * 基于查询删除数据
     */
    public static void deleteDataByQuery() throws IOException {
        String indexName = "movie_test_api";
        DeleteByQueryRequest deleteByQueryRequest = new DeleteByQueryRequest(indexName);
        //query
        MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("movieName", "湄公河");
        deleteByQueryRequest.setQuery(matchQueryBuilder);

        esClient.deleteByQuery(deleteByQueryRequest , RequestOptions.DEFAULT);
    }


    /**
     * 基于docId修改数据
     */
    public static void updateData() throws IOException {
        String indexName = "movie_test_api" ;
        String docId  = "v0PF1YAB579J1YxZTE88" ;
        UpdateRequest updateRequest = new UpdateRequest(indexName , docId );
        updateRequest.doc("movieName" ,"水门桥");
        esClient.update(updateRequest , RequestOptions.DEFAULT);
    }

    /**
     * 基于查询修改数据
     */
    public static void updateDataByQuery() throws IOException {
        String indexName = "movie_index" ;
        UpdateByQueryRequest updateByQueryRequest = new UpdateByQueryRequest(indexName);
        //query
        MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("name.keyword", "incident red sea");
        updateByQueryRequest.setQuery(matchQueryBuilder);

        //script
        HashMap<String, Object> params = new HashMap<>();
        params.put("newName","shangguigu");
        Script script = new Script(
                ScriptType.INLINE ,
                Script.DEFAULT_SCRIPT_LANG ,
                "ctx._source['actorList'][0]['name']=params.newName",
                params );
        updateByQueryRequest.setScript(script);

        esClient.updateByQuery(updateByQueryRequest , RequestOptions.DEFAULT);
    }


    /**
     * 批量写入数据
     */
    public static void bulkInsertData() throws IOException {
        ArrayList<Movie> movies = new ArrayList<>();
        movies.add(new Movie("1002", "湄公河行动")) ;
        movies.add(new Movie("1003", "八佰")) ;
        movies.add(new Movie("1004", "长津湖")) ;

        String indexName = "movie_test_api" ;

        BulkRequest bulkRequest = new BulkRequest(indexName); // 指定全局索引名字

        for (Movie movie : movies) {
            IndexRequest indexRequest = new IndexRequest();
            indexRequest.id(movie.getId());
            indexRequest.source(JSON.toJSONString(movie),XContentType.JSON);
            bulkRequest.add(indexRequest);
        }
        esClient.bulk(bulkRequest , RequestOptions.DEFAULT);
    }

    /**
     * 单条写入数据
     * 1. 幂等写，需要指定docId
     * 2. 非幂等写,不指定docId
     *
     * movie_test_api
     */
    public static void insertData() throws IOException {
        Movie movie = new Movie("1001", "红海行动");
        String indexName  = "movie_test_api" ;
        IndexRequest indexRequest = new IndexRequest(indexName);
        //指定索引名
        //indexRequest.index(indexName);
        //指定数据
        indexRequest.source(JSON.toJSONString(movie) , XContentType.JSON);
        //指定docId
        //indexRequest.id(movie.getId());

        esClient.index(indexRequest , RequestOptions.DEFAULT);
    }


    /**
     * 客户端对象
     */
    private static   RestHighLevelClient esClient = null ;
    /**
     * 创建客户端对象
     */
    static {
        HttpHost httpHost = new HttpHost("hadoop102",9200);
        RestClientBuilder restClientBuilder = RestClient.builder(httpHost);
        esClient = new RestHighLevelClient(restClientBuilder);
    }


}

class Movie{

    private String id;
    private String movieName ;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public Movie(String id, String movieName) {
        this.id = id;
        this.movieName = movieName;
    }
}